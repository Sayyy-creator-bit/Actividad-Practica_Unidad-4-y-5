var imagCI, imagCF, imagCG, imagCH;
imagCF= document.getElementById("imag");//onmouse up-down 
imagCI= document.getElementById("imaC");
imagCG= document.getElementById("ima");
imagCH= document.getElementById("imaD");


//evento  onmouseup y onmousedown
imagCF.onmousedown=function(){
  imagCI.src ="atardecer2.jpg"
}
imagCG.onmousedown=function(){
  imagCH.src ="perro2.jpg"
}

imagCF.onmouseup=function(){
  imagCI.setAttribute("src", "atardecer1.jpg");
}
imagCG.onmouseup=function(){
  imagCH.setAttribute("src", "perro1.jpg");
}

