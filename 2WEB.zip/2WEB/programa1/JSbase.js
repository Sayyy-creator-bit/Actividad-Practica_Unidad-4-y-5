//ENCONTRAS DOCUMENTOS
console.log(document.head)
console.log(document.title)
console.log(document.body)
// a. Mostrar el Número de Artículos que existen en el Documento.
var numeroDeArticulos = document.getElementsByTagName('article').length;
console.log('Número de artículos:', numeroDeArticulos);

// b. Identificar líneas divisorias dentro del Documento y número de líneas.
var lineasDivisorias = document.getElementsByTagName('hr');
console.log('Número de líneas divisorias:', lineasDivisorias.length);

// c. Identificar los elementos de lista dentro del Documento y número de elementos en total.
var elementosDeLista = document.getElementsByTagName('li');
console.log('Número total de elementos de lista:', elementosDeLista.length);

// d. Identificar elementos de la “Lista Elementos”, número de elementos y código del enlace dentro de dicha lista.
var listaElementos = document.getElementById('elemen');
var elementosEnLista = listaElementos.getElementsByTagName('li');
console.log('Número de elementos en Lista Elementos:', elementosEnLista.length);

// Obtener el código del enlace dentro de la lista
var codigoEnlaceListaElementos = listaElementos.getElementsByTagName('a')[0].getAttribute('href');
console.log('Código del enlace en Lista Elementos:', codigoEnlaceListaElementos);

// e. Identificar elementos de la lista “Menú”, identificar enlaces y número de enlaces en dicha lista.
var listaMenu = document.getElementById('menu');
var enlacesEnListaMenu = listaMenu.getElementsByTagName('a');
console.log('Número de enlaces en Lista Menú:', enlacesEnListaMenu.length);

// f. Identificar imágenes dentro del Documento y número de imágenes en total.
var imagenesEnDocumento = document.getElementsByTagName('img');
console.log('Número total de imágenes:', imagenesEnDocumento.length);

// g. Identificar imágenes del bloque referente al “Artículo 2”, identificar primera imagen y número total de imágenes dentro de este bloque.
var imagenesEnArticulo2 = document.getElementById('text2').getElementsByTagName('img');
console.log('Número total de imágenes en Artículo 2:', imagenesEnArticulo2.length);
if (imagenesEnArticulo2.length > 0) {
    var primeraImagenArticulo2 = imagenesEnArticulo2[0].getAttribute('src');
    console.log('Fuente de la primera imagen en Artículo 2:', primeraImagenArticulo2);
}

// h. Identificar imágenes del bloque referente al “Artículo 3”, número de imágenes y código referente a la segunda y cuarta imagen del presente bloque.
var imagenesEnArticulo3 = document.getElementById('text3').getElementsByTagName('img');
console.log('Número total de imágenes en Artículo 3:', imagenesEnArticulo3.length);
if (imagenesEnArticulo3.length >= 4) {
    var segundaImagenArticulo3 = imagenesEnArticulo3[1].getAttribute('src');
    var cuartaImagenArticulo3 = imagenesEnArticulo3[3].getAttribute('src');
    console.log('Fuente de la segunda imagen en Artículo 3:', segundaImagenArticulo3);
    console.log('Fuente de la cuarta imagen en Artículo 3:', cuartaImagenArticulo3);
}

// i. Identificar enlaces del Documento y número de enlaces en total.
var enlacesEnDocumento = document.getElementsByTagName('a');
console.log('Número total de enlaces:', enlacesEnDocumento.length);

// j. Identificar enlaces distribuidos dentro del párrafo referente al “Artículo 1” y número de enlaces.
var enlacesEnArticulo1 = document.getElementById('text1').getElementsByTagName('a');
console.log('Número de enlaces en Artículo 1:', enlacesEnArticulo1.length);